<template>
  <div class="overflow-hidden rounded-lg bg-white shadow">
    <div class="px-4 py-5 sm:px-6">
      <!-- Content goes here -->
      <!-- We use less vertical padding on card headers on desktop than on body sections -->
    </div>
    <div class="bg-gray-50 px-4 py-5 sm:p-6">
      <!-- Content goes here -->
    </div>
  </div>
</template>
