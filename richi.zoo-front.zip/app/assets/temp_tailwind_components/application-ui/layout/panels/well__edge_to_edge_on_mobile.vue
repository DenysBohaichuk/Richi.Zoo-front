<template>
  <!-- Be sure to use this with a layout container that is full-width on mobile -->
  <div class="overflow-hidden bg-gray-50 sm:rounded-lg">
    <div class="px-4 py-5 sm:p-6">
      <!-- Content goes here -->
    </div>
  </div>
</template>
