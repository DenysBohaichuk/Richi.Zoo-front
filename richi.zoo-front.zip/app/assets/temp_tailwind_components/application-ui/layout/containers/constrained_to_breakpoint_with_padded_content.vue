<template>
  <div class="container mx-auto px-4 sm:px-6 lg:px-8">
    <!-- Content goes here -->
  </div>
</template>
