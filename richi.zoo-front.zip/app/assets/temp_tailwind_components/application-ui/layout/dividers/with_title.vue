<template>
  <div class="relative">
    <div class="absolute inset-0 flex items-center" aria-hidden="true">
      <div class="w-full border-t border-gray-300" />
    </div>
    <div class="relative flex justify-center">
      <span class="bg-white px-3 text-base font-semibold leading-6 text-gray-900">Projects</span>
    </div>
  </div>
</template>
