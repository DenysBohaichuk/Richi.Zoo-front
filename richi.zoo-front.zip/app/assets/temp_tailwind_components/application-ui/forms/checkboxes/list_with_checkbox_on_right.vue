<!--
  This example requires some changes to your config:
  
  ```
  // tailwind.config.js
  module.exports = {
    // ...
    plugins: [
      // ...
      require('@tailwindcss/forms'),
    ],
  }
  ```
-->
<template>
  <fieldset class="border-b border-t border-gray-200">
    <legend class="sr-only">Notifications</legend>
    <div class="divide-y divide-gray-200">
      <div class="relative flex items-start pb-4 pt-3.5">
        <div class="min-w-0 flex-1 text-sm leading-6">
          <label for="comments" class="font-medium text-gray-900">Comments</label>
          <p id="comments-description" class="text-gray-500">Get notified when someones posts a comment on a posting.</p>
        </div>
        <div class="ml-3 flex h-6 items-center">
          <input id="comments" aria-describedby="comments-description" name="comments" type="checkbox" class="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-600" />
        </div>
      </div>
      <div class="relative flex items-start pb-4 pt-3.5">
        <div class="min-w-0 flex-1 text-sm leading-6">
          <label for="candidates" class="font-medium text-gray-900">Candidates</label>
          <p id="candidates-description" class="text-gray-500">Get notified when a candidate applies for a job.</p>
        </div>
        <div class="ml-3 flex h-6 items-center">
          <input id="candidates" aria-describedby="candidates-description" name="candidates" type="checkbox" class="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-600" />
        </div>
      </div>
      <div class="relative flex items-start pb-4 pt-3.5">
        <div class="min-w-0 flex-1 text-sm leading-6">
          <label for="offers" class="font-medium text-gray-900">Offers</label>
          <p id="offers-description" class="text-gray-500">Get notified when a candidate accepts or rejects an offer.</p>
        </div>
        <div class="ml-3 flex h-6 items-center">
          <input id="offers" aria-describedby="offers-description" name="offers" type="checkbox" class="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-600" />
        </div>
      </div>
    </div>
  </fieldset>
</template>
