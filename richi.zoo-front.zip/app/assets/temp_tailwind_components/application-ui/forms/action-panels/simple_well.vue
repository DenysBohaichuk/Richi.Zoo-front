<template>
  <div class="bg-gray-50 sm:rounded-lg">
    <div class="px-4 py-5 sm:p-6">
      <h3 class="text-base font-semibold leading-6 text-gray-900">Need more bandwidth?</h3>
      <div class="mt-2 max-w-xl text-sm text-gray-500">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus praesentium tenetur pariatur.</p>
      </div>
      <div class="mt-5">
        <button type="button" class="inline-flex items-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50">Contact sales</button>
      </div>
    </div>
  </div>
</template>
