<template>
  <div class="bg-white shadow sm:rounded-lg">
    <div class="px-4 py-5 sm:p-6">
      <h3 class="text-base font-semibold leading-6 text-gray-900">Continuous Integration</h3>
      <div class="mt-2 max-w-xl text-sm text-gray-500">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, totam at reprehenderit maxime aut beatae ad.</p>
      </div>
      <div class="mt-3 text-sm leading-6">
        <a href="#" class="font-semibold text-indigo-600 hover:text-indigo-500">
          Learn more about our CI features
          <span aria-hidden="true"> &rarr;</span>
        </a>
      </div>
    </div>
  </div>
</template>
