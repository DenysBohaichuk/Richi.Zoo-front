<template>
  <span class="inline-flex h-6 w-6 items-center justify-center rounded-full bg-gray-500">
    <span class="text-xs font-medium leading-none text-white">TW</span>
  </span>

  <span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-gray-500">
    <span class="text-sm font-medium leading-none text-white">TW</span>
  </span>

  <span class="inline-flex h-10 w-10 items-center justify-center rounded-full bg-gray-500">
    <span class="font-medium leading-none text-white">TW</span>
  </span>

  <span class="inline-flex h-12 w-12 items-center justify-center rounded-full bg-gray-500">
    <span class="text-lg font-medium leading-none text-white">TW</span>
  </span>

  <span class="inline-flex h-14 w-14 items-center justify-center rounded-full bg-gray-500">
    <span class="text-xl font-medium leading-none text-white">TW</span>
  </span>
</template>
