<template>
  <button type="button" class="rounded-full bg-indigo-600 p-1 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
    <PlusIcon class="h-5 w-5" aria-hidden="true" />
  </button>
  <button type="button" class="rounded-full bg-indigo-600 p-1.5 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
    <PlusIcon class="h-5 w-5" aria-hidden="true" />
  </button>
  <button type="button" class="rounded-full bg-indigo-600 p-2 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
    <PlusIcon class="h-5 w-5" aria-hidden="true" />
  </button>
</template>

<script setup>
import { PlusIcon } from '@heroicons/vue/20/solid'
</script>